import React from "react";
function RegisterSuccess(){
    return(
        <div>
            <h1>helloworld</h1>
        </div>
    )
}
export default RegisterSuccess;