import React, { useState } from "react";
import './Register.css';
import axios from "axios";
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import { FaInfoCircle } from "react-icons/fa";
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import { styled } from '@mui/material/styles';
const Register = () => {
    const HtmlTooltip = styled(({ className, ...props }) => (
        <Tooltip {...props} classes={{ popper: className }} />
    ))(({ theme }) => ({
        [`& .${tooltipClasses.tooltip}`]: {
            backgroundColor: '#f5f5f9',
            color: 'rgba(0, 0, 0, 0.87)',
            maxWidth: 220,
            fontSize: theme.typography.pxToRem(12),
            border: '1px solid #dadde9',
        },
    }));
    const navigate = useNavigate();
    const tooltiptext=
    "*Password should contain atleast 8 characters \n *Password should contain atleast one character \n *Password should contain upper and lowercase letters.";
    const [errors, setErrors] = useState({});
    const [userdata, setUserdata] = useState({
        firstname: '',
        lastname: '',
        email: '',
        username: '',
        dateofbirth: '',
        gender: '',
        password: '',
        reenterpassword: '',
    })
    const onInputChange = (e) => {
        e.preventDefault();
        setUserdata({ ...userdata, [e.target.name]: e.target.value });
    }
    const onDateChange = (e) => {
        e.preventDefault();
        const formatteddate = new Date(e.target.value).toISOString().split('T')[0];
        console.log(formatteddate);
        setUserdata({ ...userdata, dateofbirth: formatteddate })
    }
    const validateForm = () => {
        let formErrors = {};
        if (!userdata.firstname.trim() && !userdata.lastname.trim() && !userdata.username.trim() && !userdata.password.trim() && !userdata.reenterpassword.trim()) {
            formErrors.firstname = "*This field is required";
            formErrors.lastname = "*This field is required";
            formErrors.username = "*This field is required";
            formErrors.password = "*This field is required";
            formErrors.reenterpassword = "*This field is required";

        }
        if (!userdata.email.trim()) {
            formErrors.email = "*This field is required";
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userdata.email)) {
            formErrors.email = "*email should contain @!";
        }
        if (!userdata.dateofbirth && !userdata.gender) {
            formErrors.dateofbirth = "*Please select a date";
            formErrors.gender = "*Select any one option";
        }
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(userdata.password)) {
            formErrors.password = "*Special characters required";
        } else if (!/^(?=.*[a-z])(?=.*[A-Z])/.test(userdata.password)) {
            formErrors.password = "*Password should contain atleast one uppercase letter";
        }
        if (userdata.password !== userdata.reenterpassword) {
            formErrors.reenterpassword = "*This field must match password";
        }
        setErrors(formErrors);
        return Object.keys(formErrors).length === 0;
    }
    const submitForm = async (e) => {
        e.preventDefault();
        if (validateForm()) {
            await axios.post("http://localhost:8088/api/register", userdata);
            navigate('/registersuccess');
            // alert("user registration successfull.");
            console.log(userdata);
        }
    }
    const gotologin = () => {
        navigate('/login');
    }
    return (
        <div id="reg-formbody">
            <img src="./images/reg-bg1.png" id="reg-img" />
            <form id="reg-form">
                <Box sx={{ display: 'flex' }} className="loader">
                    <CircularProgress id="spinner" />
                </Box>
                <table>
                    <th><h3 id="reg-header">Register here</h3></th>
                    <tr>
                        <td><label className="reg-labels">Firstname</label><br />
                            <input
                                className="reg-data"
                                type="text"
                                placeholder="Enter your firstname"
                                name="firstname"
                                value={userdata.firstname}
                                onChange={(e) => onInputChange(e)} 
                                style={{borderColor:errors.firstname?'red':''}}/>
                        </td>
                    </tr>
                    <tr><td>{errors.firstname && <span className="reg-error">{errors.firstname}</span>}</td></tr>
                    <tr>
                        <td><label className="reg-labels">Lastname</label><br />
                            <input
                                className="reg-data"
                                type="text"
                                placeholder="Enter your lastname"
                                name="lastname"
                                value={userdata.lastname}
                                onChange={(e) => onInputChange(e)} 
                                style={{borderColor:errors.lastname?'red':''}}/>
                        </td>
                    </tr>
                    <tr><td>{errors.lastname && <span className="reg-error">{errors.lastname}</span>}</td></tr>
                    <tr>
                        <label className="reg-labels">Email</label><br />
                        <input
                            className="reg-data"
                            type="email"
                            placeholder="Enter your EmailID"
                            name="email"
                            value={userdata.email}
                            onChange={(e) => onInputChange(e)} 
                            style={{borderColor:errors.email?'red':''}}/>
                    </tr>
                    <tr><td>{errors.email && <span className="reg-error">{errors.email}</span>}</td></tr>
                    <tr>
                        <label className="reg-labels">Username<br />
                            <input
                                className="reg-data"
                                type="text"
                                placeholder="Enter your username"
                                name="username"
                                value={userdata.username}
                                onChange={(e) => onInputChange(e)} 
                                style={{borderColor:errors.username?'red':''}}/></label>
                    </tr>
                    <tr><td>{errors.username && <span className="reg-error">{errors.username}</span>}</td></tr>
                    <tr>
                        <td><label className="reg-labels">Date of Birth</label><br />
                            <input
                                className="reg-data"
                                type="date"
                                placeholder="Enter your date of birth"
                                name="dateofbirth"
                                value={userdata.dateofbirth}
                                onChange={(e) => onDateChange(e)} 
                                style={{borderColor:errors.dateofbirth?'red':''}}/>
                        </td>
                    </tr>
                    <tr><td>{errors.dateofbirth && <span className="reg-error">{errors.dateofbirth}</span>}</td></tr>
                    <tr>
                        <td><label className="reg-labels">Gender</label><br />
                            <select id="select" name="gender" value={userdata.gender} onChange={(e) => onInputChange(e)} className="reg-data" style={{borderColor:errors.gender?'red':''}}>
                                <option value="">---select---</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </td>
                    </tr>
                    <tr><td>{errors.gender && <span className="reg-error">{errors.gender}</span>}</td></tr>
                    <tr>
                        <label className="reg-labels">Password</label><br />
                        <input
                            className="reg-data"
                            type="password"
                            placeholder="Enter your password"
                            name="password"
                            value={userdata.password}
                            onChange={(e) => onInputChange(e)} 
                            style={{borderColor:errors.password?'red':''}}/>
                            <Tooltip title={tooltiptext} arrow>
                        <p id="info-circle">i</p>
                    </Tooltip>
                    </tr>
                    <tr><td>{errors.password && <span className="reg-error">{errors.password}</span>}</td></tr>
                    <tr>
                        <label className="reg-labels">Confirm Password</label><br />
                        <input
                            className="reg-data"
                            type="password"
                            placeholder="Re-enter Password"
                            name="reenterpassword"
                            value={userdata.reenterpassword}
                            onChange={(e) => onInputChange(e)} 
                            style={{borderColor:errors.reenterpassword?'red':''}}/>
                    </tr>
                    <tr><td>{errors.reenterpassword && <span className="reg-error">{errors.reenterpassword}</span>}</td></tr>
                    <tr>
                        <p>Already had account ?click on <a onClick={gotologin} id="navlogin">login</a></p>
                    </tr>
                    <tr>
                        <Button variant="contained" size="medium" onClick={submitForm}>
                            Register
                        </Button>
                    </tr>
                </table>

            </form>
        </div>
    )
}
export default Register;