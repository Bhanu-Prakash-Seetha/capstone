import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams, Link } from "react-router-dom";
const LoginHome = () => {
    const navigate = useNavigate();
    const { username } = useParams();
    const [selectedValue, setselectedValue] = useState({username});
    const handleLogout = async (event) => {
        const selectedOption = event.target.value;
        setselectedValue(selectedOption);
        if (selectedOption === 'logout') {
            try {
                const response = await axios.post('http://localhost:8088/api/logout');
                if (response.status === 200) {
                    navigate('/login');
                } else {
                    console.log("logout failed");
                }
            } catch (error) {
                console.log("Logout error", error);
            }
        }
        else if (selectedOption === 'settings') {
            navigate('/settings')
        }
    }
    return (
        <div>
            <h2>Welcome</h2>
            {/* <h2>{username}</h2> */}
            <select value={selectedValue} onChange={handleLogout} >
                <option>{username}</option>
                <option value='settings'>Settings</option>
                <option value='logout'>Logout</option>
            </select>
        </div>
    )
}
export default LoginHome
