import React from 'react'

function Settings() {
  return (
    <div>
     Hello Settings 
    </div>
  )
}
export default Settings
