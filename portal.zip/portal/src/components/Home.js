import React from "react";
import Navbar from "./navbar";
const HomePage = ()=>{
    return(
        <div>
            <Navbar />
            
        </div>
    )
}
export default HomePage;