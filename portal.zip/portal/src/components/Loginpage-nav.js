import React from "react";
function LoginpageNAv(){
    return(
        <div>
            
        </div>
    )
}