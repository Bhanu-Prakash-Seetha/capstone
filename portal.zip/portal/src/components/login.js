import React, { useState } from "react";
import axios from "axios";
import './login.css';
import { Link, useNavigate } from "react-router-dom";
import Button from '@mui/material/Button';
function Login({onlogin}) {
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});
    const validateLoginForm = () => {
        let formErrors = {};
        if (!username.trim()) {
            formErrors.username = "*Username is required!";
        }
        if (!password.trim()) {
            formErrors.password = "*Password is required!";
        }
        if (!/\S+@\S+/.test(password)) {
            formErrors.password = "*password should contain special characters";
        }
        /* if(!/A-Za-z0-9/.test(password)){
             formErrors.password="*password should contain Uppercase and lowercase!"
         }*/
        if (password.length < 8) {
            formErrors.password = "*password should contain atleast 8 characters";
        }
        setErrors(formErrors);
        console.log(setErrors(formErrors));
        return Object.keys(formErrors).length === 0;
    }
    const getLogin = async (e) => {
        try {
            e.preventDefault();
            if (validateLoginForm()) {
                const response = await axios.post("http://localhost:8088/api/login", {
                    username,
                    password,
                });
                const ResponseData = response.data
                console.log(ResponseData);
                localStorage.setItem("usertoken", ResponseData);
                onlogin(response.data)
                navigate(`/loginHome/${response.data}`);
                console.log("login success", response.data);
                //return <div>{response.data}</div>
            } else {
                console.log("errors occured");
            }
        } catch (e) {
            alert("bad credentials");
        }

    }
    const gotoregister = () => {
        navigate('/register')
    }
    return (
        <div id="body">
            <form id="form-body">
                <center>
                    <table id="login-tb">
                        <tbody>
                        <tr id="row1">
                            <h3 id="header">Login here</h3>
                        </tr>
                        <tr><td><label className="login-label">Username/EmailId<br /><br />
                            <input
                                className="login-data"
                                type="text"
                                name="emailorUsername"
                                value={username}
                                placeholder="Enter username or emailid"
                                onChange={(e) => setUsername(e.target.value)}
                                style={{ borderColor: errors.username ? 'red' : '' }}
                            />
                        </label></td>
                        </tr>
                        <tr>{errors && <span severity="error" className="error">{errors.username}</span>}</tr><br />
                        <tr><td><label className="login-label">Password<br /><br />
                            <input type="password"
                                className="login-data"
                                name="password"
                                value={password}
                                placeholder="Enter your password"
                                onChange={(e) => setPassword(e.target.value)}
                                style={{ borderColor: errors.password ? 'red' : '' }} />
                        </label></td>
                        </tr>
                        <tr>{errors && <span severity="error" className="error">{errors.password}</span>}</tr><br />
                        <tr><h4>To create account click on <a id="navreg" onClick={gotoregister}>Register</a></h4></tr>
        
                        <Button variant="contained" size="medium" onClick={getLogin} className="login-btn">
                            Login
                        </Button>
                        </tbody>
                    </table>
                </center>
            </form>
        </div>
    )
}
export default Login;