import React, { useState } from "react";
import MenuSharpIcon from '@mui/icons-material/MenuSharp';
import { CircularProgress } from "@mui/material";
import './navbar.css';
import CloseIcon from '@mui/icons-material/Close';
import { NavLink, useNavigate } from "react-router-dom";
const Navbar = () => {
    const [loading, setloading] = useState(false);
    const navigate = useNavigate();
    const [selectedOption, setselectedOption] = useState('Account');
    /*const redirect = () => {
        setloading(true);
        setTimeout(() => {
            setloading(false);
            window.location.href = '/home';
        }, 10000);
    };*/
    const handleoptionChange = (event) => {
        const selectedValue = event.target.value;
        setselectedOption(selectedValue);
        if (selectedValue === 'login') {
            navigate('/login');
        } else if (selectedValue === 'register') {
            navigate('/register');
        }
    }
    return (
        <div>
            <nav class="navbar">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Logos.svg/800px-Logos.svg.png" />
                {/* <img src="./images/edu.jpg" id=""/> */}
                <input type="checkbox" id="check" />
                <label for="check">
                    <MenuSharpIcon id="menu-tool" />
                    <CloseIcon id="close-tool" />
                </label>
                <ul>
                    <li><a>Home</a></li>
                    <li><a>About</a></li>
                    <li><a>Services</a></li>
                    <li><a>Team</a></li>
                    <li><a>
                        <select value={selectedOption} onChange={handleoptionChange}>
                            <option>Creact Account</option>
                            <option value='register' >Register</option>
                            <option value='login'>Login</option>
                        </select>
                    </a></li>
                </ul>
            </nav>
            {/*loading ? (
                <CircularProgress id="load-spinner" />) : (
                <NavLink to={"/home"}>
                    <button onClick={redirect}>Click</button>
                </NavLink>
            )
                */}


        </div>

    )
}
export default Navbar;