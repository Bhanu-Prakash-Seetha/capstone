import logo from './logo.svg';
import './App.css';
import {Router, Routes,Route, Navigate } from 'react-router-dom';
import Login from './components/login';
import Register from './RegisterComponents/Register';
import HomePage from './components/Home';
import RegisterSuccess from './RegisterComponents/RegisterSuccess';
import LoginHome from './components/LoginHome';
import Settings from './components/Settings';
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={ <HomePage/>}/>
        <Route path='/login' element={<Login onlogin={(username)=><Navigate to={`/loginHome/${username}`}/>}/>}/>
        <Route path='/register' element={<Register/>}/>
        <Route path='/registersuccess' element={<RegisterSuccess/>}/>
        <Route path='/loginHome/:username' element={<LoginHome />}/>
        <Route path='/settings' element={<Settings/>}/>
      </Routes>
    
    </div>
  );
}

export default App;
