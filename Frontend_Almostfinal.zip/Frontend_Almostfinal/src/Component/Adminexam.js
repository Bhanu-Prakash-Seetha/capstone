import React from "react";
import Navbaradmin from "./Navbaradmin";
import ShowQuestions from "./ShowQuestions";
import EditQuestionModal from "./EditQuestionModel";
import ShowUserResponse from "./ShowUserResponse";
import QuizGenerator from "./QuizGenerator";
import QuizPage from "./QuizPage";
function Adminexam(){
return(
    <div>
        <Navbaradmin/>
        Adminexam
    </div>
)
}
 
export default Adminexam