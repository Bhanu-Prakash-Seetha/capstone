import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import Navbaradmin from "./Navbaradmin";
export default function Adminsurvey() {
    const [surveys, setSurvey] = useState([]);

    const { id } = useParams();

    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        const result = await axios.get("http://localhost:8080/sur/v1/surveys");
        setSurvey(result.data);
    };

    const deleteUser = async (id) => {
        await axios.delete(`http://localhost:8080/sur/v1/survey/${id}`);
        loadUsers();
    };

    return (
        <div>
            <Navbaradmin />
            <div className="container">
                <div className="py-6">
                    <center>
                        <table className="table border shadow" >
                            <thead>
                                <tr>
                                    <th scope="col">S.N</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Profession</th>
                                    <th scope="col">Interests</th>
                                    <th scope="col">DomainIntrested</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {surveys.map((survey, index) => (
                                    <tr>
                                        <th scope="row" key={index}>
                                            {index + 1}
                                        </th>
                                        <td>{survey.username}</td>
                                        <td>{survey.email}</td>
                                        <td>{survey.profession}</td>
                                        <td>{survey.interest}</td>
                                        <td>{survey.domain}</td>
                                        <td>
                                            <Link
                                                className="btn btn-primary mx-2"
                                                to={`/adminview/${survey.id}`}
                                            >
                                                View
                                            </Link>
                                            <button
                                                class=" px-12 py-2 text-sm font-end tracking-wide text-white capitalize transition-colors md:text-center duration-300 transform bg-blue-400 rounded-md hover:bg-blue-400"
                                                onClick={() => deleteUser(survey.id)}
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </center>
                </div>
            </div>
        </div>
    );
}
