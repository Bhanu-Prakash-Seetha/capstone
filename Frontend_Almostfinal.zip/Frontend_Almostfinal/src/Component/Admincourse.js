import React from "react";
import Navbaradmin from "./Navbaradmin";
function Admincourse(){
return(
    <div>
        <Navbaradmin/>
        Admincourse
    </div>
)
}
 
export default Admincourse