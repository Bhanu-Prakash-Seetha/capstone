package com.infinite.portal.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.portal.model.UserEntity;
@Repository
public class UserEntityDaoImpls implements UserEntityDao{
	@Autowired SessionFactory sfactory;
	@Override
	@Transactional
	public void register(UserEntity userEntity) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(userEntity);
	}
	@Override
	@Transactional
	public List<UserEntity> getAllData() {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		List<UserEntity> list = session.createQuery("from UserEntity").list();
		return list;
	}
	@Override
	@Transactional
	public UserEntity validateuser(String username, String password) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		Query query=session.createQuery("FROM UserEntity WHERE username= :username AND password= :password");
		query.setParameter("username", username);
		query.setParameter("password", password);
		UserEntity validateuser=(UserEntity) query.uniqueResult();
		System.out.println(validateuser);
		return validateuser;
		}
	@Transactional
	public UserEntity updatedata(String username,String password) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		Query query = session.createQuery("update UserEntity SET username=:username and password=:password WHERE id=:id");
		query.setParameter("username", username);
		query.setParameter("password", password);
		query.executeUpdate();
		return (UserEntity) query;
		
	}
	
	
	
	

}
