package com.infinite.portal.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.infinite.portal.model.UserEntity;
import com.infinite.portal.service.UserServiceImpls;

@RestController
@CrossOrigin("http://localhost:3000/")
@RequestMapping("/api")
public class UserEnitityController {
	@Autowired UserServiceImpls usi;
	//@Autowired private AuthService authService;
	@PostMapping("/register")
	public void userRegister(@RequestBody UserEntity userEntity) {
		 usi.register(userEntity);
	}
	@GetMapping("/fetch")
	public List<UserEntity> fetchalldata(){
		return usi.getAllData();
	}
	@PostMapping("/login")
	public ResponseEntity<String> userLogin(@RequestBody UserEntity userEntity ,HttpSession session){
		String username = userEntity.getUsername();
		String password = userEntity.getPassword();
		UserEntity user = usi.validateuser(username, password);
		if(user!=null) {
			session.setAttribute("user", user);
			return ResponseEntity.ok(username);
		}else {
           return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("invalid credintials");
		}
	}
	@GetMapping("/user/{username}")
	public ResponseEntity<UserEntity> getUserbyUsername(@PathVariable String username){
		UserEntity user = usi.getUserbyUsername(username);
		if(user!=null) {
			return ResponseEntity.ok(user);
		}else {
	           return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);

		}
	}
	@PostMapping("/logout")
	public String getLogout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		if (session!=null) {
			session.invalidate();
		}
		return "redirect:/logout?logout";
	}
	@GetMapping("/loggedinusername")
	public ResponseEntity<String> getLoggedInUser(HttpSession session){
		String user = (String) session.getAttribute("user");
		if(user!=null) {
			return ResponseEntity.ok("Logged in User : "+ user);
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("not logged in");
		}
	}
}
