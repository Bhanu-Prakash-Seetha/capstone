package com.infinite.portal.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.portal.dao.UserEntityDaoImpls;
import com.infinite.portal.model.UserEntity;

@Service
public class UserServiceImpls implements UserService{
	@Autowired UserEntityDaoImpls userDao;
	@Override
	public void register(UserEntity userEntity) {
		// TODO Auto-generated method stub
		userDao.register(userEntity);
	}
	@Override
	public List<UserEntity> getAllData() {
		// TODO Auto-generated method stub
		return userDao.getAllData();
	}
	@Override
	public UserEntity validateuser(String username, String password) {
		// TODO Auto-generated method stub
		return userDao.validateuser(username, password);
	}
	public UserEntity updatedata(String username, String password) {
		// TODO Auto-generated method stub
		return userDao.updatedata(username, password);
	}
	@Override
	public UserEntity getUserbyUsername(String username) {
		// TODO Auto-generated method stub
		return ((UserService) userDao).getUserbyUsername(username);
	}
	
	
	
	
}
