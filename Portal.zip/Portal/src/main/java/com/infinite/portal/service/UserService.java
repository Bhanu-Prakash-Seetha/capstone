package com.infinite.portal.service;

import java.util.List;

import com.infinite.portal.model.UserEntity;

public interface UserService {
	public void register(UserEntity userEntity);
	List<UserEntity> getAllData();
	public UserEntity validateuser(String username, String password);
	public UserEntity updatedata(String username,String password);
	public UserEntity getUserbyUsername(String username);
	}
