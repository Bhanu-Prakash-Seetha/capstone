package com.infinite.questions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.questions.entity.Questionpojo;
import com.infinite.questions.service.QServiceimpls;

@RestController
@CrossOrigin("http://localhost:3000/")
@RequestMapping("/api")
public class MyController {
	@Autowired
	QServiceimpls qsi;

	@RequestMapping(value = "/questions", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> addQuestion(@RequestBody Questionpojo qpojo) {
		try {
			qsi.addCustomer(qpojo);
			return ResponseEntity.ok("Questions added successfully");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Questions adding failed");

		}

	}
	@GetMapping("/getdata")
	public List<Questionpojo> getAllQuestions() {
		List<Questionpojo> questions = qsi.getAllQuestions();
		return qsi.getAllQuestions();
	}
}
