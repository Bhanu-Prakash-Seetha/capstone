package com.infinite.questions.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.questions.dao.Questionimpls;
import com.infinite.questions.entity.Questionpojo;
@Service
public class QServiceimpls implements IService{
	@Autowired Questionimpls qi;
	@Override
	public Questionpojo addCustomer(Questionpojo qpojo) {
		// TODO Auto-generated method stub
		return qi.addCustomer(qpojo);
	}
	@Override
	public List<Questionpojo> getAllQuestions() {
		// TODO Auto-generated method stub
		return qi.getAllQuestions();
	}

}
