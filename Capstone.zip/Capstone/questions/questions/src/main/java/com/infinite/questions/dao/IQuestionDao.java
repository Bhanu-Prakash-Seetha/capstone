package com.infinite.questions.dao;

import java.util.List;

import com.infinite.questions.entity.Questionpojo;

public interface IQuestionDao {
	public Questionpojo addCustomer(Questionpojo qpojo);
	public List<Questionpojo> getAllQuestions();

}
