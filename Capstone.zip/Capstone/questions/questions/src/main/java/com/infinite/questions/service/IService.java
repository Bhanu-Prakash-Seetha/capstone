package com.infinite.questions.service;

import java.util.List;
import com.infinite.questions.entity.Questionpojo;

public interface IService {
	public Questionpojo addCustomer(Questionpojo qpojo);
	public List<Questionpojo> getAllQuestions();

}
