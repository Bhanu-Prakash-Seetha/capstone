package com.infinite.questions.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.questions.entity.Questionpojo;

@Repository
@EnableAsync(proxyTargetClass = true)
@EnableCaching(proxyTargetClass = true)
@EnableTransactionManagement
public class Questionimpls implements IQuestionDao {
	@Autowired
	SessionFactory sfactory;

	public void setSfactory(SessionFactory sfactory) {
		this.sfactory = sfactory;
	}

	@Override
	@Transactional
	public Questionpojo addCustomer(Questionpojo qpojo) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(qpojo);
		return qpojo;
	}

	@Override
	@Transactional
	public List<Questionpojo> getAllQuestions() {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		List<Questionpojo> ls = session.createQuery("FROM Questionpojo").list();
		return ls;
	}

}
