import logo from './logo.svg';
import './App.css';
import Questionform from './components/Questionform';
import Quizpage from './components/Quizpage';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';

function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<Questionform/>}/>
        <Route path="/quiz" element={<Quizpage/>}/>
      </Routes>
    </Router>
  );
};

export default App;
