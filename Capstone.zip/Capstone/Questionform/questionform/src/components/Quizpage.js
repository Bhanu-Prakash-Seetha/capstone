import React, { useState, useEffect } from 'react';
import axios from 'axios';

const QuizPage = () => {
    const [questions, setQuestions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [userAnswers, setUserAnswers] = useState({});
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

    useEffect(() => {
        axios.get('http://localhost:8080/api/getdata')
            .then(response => {
                setQuestions(response.data);
                setLoading(false);
            })
            .catch(error => {
                console.error('Error fetching questions:', error);
                setLoading(false);
            });
    }, []);

    const handleAnswerSelect = (selectedOption) => {
        setUserAnswers((prevAnswers) => ({
            ...prevAnswers,
            [currentQuestion.id]: selectedOption,
        }));
    };

    const handleNextQuestion = () => {
        setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
    };

    const handleQuizSubmit = () => {
        // Implement logic for submitting userAnswers, e.g., sending them to the server
        console.log('User answers:', userAnswers);
    };

    if (loading) {
        return <p>Loading questions...</p>;
    }

    if (questions.length === 0) {
        return <p>No questions available.</p>;
    }

    const currentQuestion = questions[currentQuestionIndex];

    return (
        <div>
            {questions.map(question => (
                <div key={question.id}>
                    <p>{question.question}</p>
                    <label>
                        <input
                            type="radio"
                            name={`answer-${question.id}`}
                            value={question.option1}
                        />
                        {question.option1}
                    </label>
                    <label>
                        <input
                            type="radio"
                            name={`answer-${question.id}`}
                            value={question.option2}
                        />
                        {question.option2}
                    </label>
                    <label>
                        <input
                            type="radio"
                            name={`answer-${question.id}`}
                            value={question.option3}
                        />
                        {question.option3}
                    </label>
                    <label>
                        <input
                            type="radio"
                            name={`answer-${question.id}`}
                            value={question.option4}
                        />
                        {question.option4}
                    </label>
                    {/* Repeat for option2, option3, and option4 */}
                </div>
            ))}
        </div>
    );
};

export default QuizPage;