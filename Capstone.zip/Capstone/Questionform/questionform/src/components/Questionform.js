import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Link, Routes,useNavigate } from 'react-router-dom';
import QuizStartpage from './QuizStartpage';
//import { unstable_HistoryRouter } from 'react-router-dom';
//import './App.css';
//import Loginform from './Loginuser';

function Questionform() {
    const [formData, setFormData] = useState({
        question: '',
        option1: '',
        option2: '',
        option3: '',
        option4: '',
        correct_option: '',
    });
    const [loading,setLoading] = useState(true);
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };
    const handleSubmit = async () => {
        try {
            const response = await axios.post('http://localhost:8080/api/questions', formData);

            if (response.status === 200) {
                console.log('Questions added successfully');
                //alert("you have successfully registered");

            } else {
                console.error('Failed to add');
            }
        } catch (error) {
            console.error('Error during adding:', error);
        }
    };
    const [questions, setQuestions] = useState([]);
    useEffect(() => {
        axios.get('http://localhost:8080/api/getdata')
            .then(response => setQuestions(response.data))
            .catch(error => console.error("error fetching questions : ", error));
    }, [])
    const navigate = useNavigate();
    console.log("questions props :",questions);
    const handleStartQuiz = () => {
        navigate('/quiz');
    }
    return (
        
            <div className="App">
                <h1>Add Questions</h1>
                <form onSubmit={handleSubmit}>
                    <label>Question</label>
                    <input type="text" name="question" onChange={handleChange} /><br />

                    <label>option1</label>
                    <input type="text" name="option1" onChange={handleChange} /><br />

                    <label>option2:</label>
                    <input type="text" name="option2" onChange={handleChange} /><br />

                    <label>option3:</label>
                    <input type="text" name="option3" onChange={handleChange} /><br />

                    <label>option4:</label>
                    <input type="text" name="option4" onChange={handleChange} /><br />

                    <label>CorrectOption:</label>
                    <input type="text" name="correct_option" onChange={handleChange} /><br />
                    <button type="button" onClick={handleSubmit}>
                        Submit
                    </button>
                </form>
                <div>
                    <h1>Quiz Questions</h1>
                    <table border={1}>
                        <thead>
                            <tr>
                                <th>Questions</th>
                                <th>options</th>
                                <th>correct option</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                Array.isArray(questions) && questions.map(question =>
                                    <tr key={question.question_id}>
                                        <td>{question.question}</td>
                                        <tr>
                                            <td>{question.option1}</td>
                                            <td>{question.option2}</td>
                                            <td>{question.option3}</td>
                                            <td>{question.option4}</td>
                                        </tr>
                                        correct_option :<tr> {question.correct_option}</tr>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>

                    <Link to="/quiz">
                        <button onClick={handleStartQuiz}>Create quiz</button>
                    </Link>
                    
                </div>
            </div>

        
    );
}

export default Questionform;