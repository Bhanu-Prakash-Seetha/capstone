import React, { useState, useEffect } from 'react';
 
const QuizComponent = ({ questions }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
 
  const handleAnswerSelect = (selectedOption) => {
    setUserAnswers(prevAnswers => [...prevAnswers, { questionId: questions[currentQuestionIndex].id, selectedOption }]);
  };
 
  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      // Quiz finished, you can handle the submission of answers here
      console.log('Quiz finished. User answers:', userAnswers);
    }
  };
 
  return (
    <div>
      <h2>Question {currentQuestionIndex + 1}</h2>
      <p>{questions[currentQuestionIndex].question}</p>
      
      <ul>
        {questions[currentQuestionIndex].options.map((option, index) => (
          <li key={index}>
            <label>
              <input
                type="radio"
                name="answer"
                value={option}
                onChange={() => handleAnswerSelect(option)}
                checked={userAnswers.find(answer => answer.questionId === questions[currentQuestionIndex].id && answer.selectedOption === option)}
              />
              {option}
            </label>
          </li>
        ))}
      </ul>
 
      <button onClick={handleNextQuestion}>Next Question</button>
    </div>
  );
};
 
export default QuizComponent;