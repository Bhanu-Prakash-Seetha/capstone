import React from "react";
import QuizComponent from "./QuizComponent";
const QuizStartpage=({questions})=>{
    console.log(questions);
    if(!questions || questions.length ===0){
        return <div>No questions available</div>
    }
    return(
        <div>
            <h2>Quiz is Starting</h2>
            <QuizComponent questions={questions}/>
        </div>
    );
}
export default QuizStartpage;